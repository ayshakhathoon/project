<?php
include 'db_con.php';
if(isset($_POST['register'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $ad_no = $_POST['ad_no'];
    $address = $_POST['address'];
    $relation = $_POST['relation'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $check = "SELECT * FROM tbl_login WHERE email='$mail'";
    $rslt = mysqli_query($conn, $check);
    $rsltcheck = mysqli_num_rows($rslt);
    if($rsltcheck == 0){
        $user_check = "SELECT `type_id` FROM `tbl_usertype` WHERE `type_name` = 'user'";
        $user_check_rslt = mysqli_query($conn,$user_check);
        while($row = mysqli_fetch_array($user_check_rslt)){
            //echo $row['type_id'];
        $type = $row['type_id'];
        $reg = "INSERT INTO `tbl_login`(`email`, `password`, `type_id`) VALUES ('$mail','$password','$type')";
        $reg_query = mysqli_query($conn,$reg);
        $last_id = mysqli_insert_id($conn);
        if($reg_query){
            $user_reg = "INSERT INTO `tbl_users`(`user_fname`, `user_lname`, `user_phone`, `user_status`, `login_id`) VALUES ('$fname','$lname','$phone','active','$last_id')";
            $user_reg_query = mysqli_query($conn,$user_reg);
            echo'<script> alert ("Account created");</script>';
            echo'<script>window.location.href="login.php";</script>'; 
        }
        }
    }
    else{
        echo'<script> alert ("Account already exists!");</script>';
        echo'<script>window.location.href="login.php";</script>'; 
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Login</title>
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Rubik:400,700"
    />
    <link rel="stylesheet" href="./style.css" />
  </head>
  <body>
  <script>
                function add()
                {
    var pw1 = document.getElementById("pass").value;
    var pw2 = document.getElementById("cpass").value;
    if(pw1 != pw2) {
        document.getElementById('msg1').style.display = "block";
        document.getElementById('msg1').innerHTML = "Password doesnot match";
        return false;
    }
    else{
        document.getElementById('msg1').style.display = "none";
    }

    var ph = document.getElementById("phn").value;
    var expr = /^[6-9]\d{9}$/;
    if(expr.test(ph)==false){
        document.getElementById('msg2').style.display = "block";
        document.getElementById('msg2').innerHTML = "Invalid Phone number";
        return false;
                }
                else{
        document.getElementById('msg2').style.display = "none";
    }
            }
                </script>
    <!-- partial:index.partial.html -->
    <div class="login-form">
      <form action="" method="post" onsubmit="return add()">
        <h1>Parent Register</h1>
        <div class="content">
          <div class="input-field">
            <input type="text" name="fname" placeholder="Enter first name" autocomplete="nope"/>
          </div>
          <div class="input-field">
            <input type="text" name="lname" placeholder="Enter last name" autocomplete="nope"/>
          </div>
          <div class="input-field">
            <input type="text" name="dob" placeholder="Enter admition no" autocomplete="nope"/>
          </div>
          <div class="input-field">
            <input type="text" name="address" placeholder="Enter address" autocomplete="nope"/>
          </div>
          <div class="input-field">
            <input type="text" name="email" placeholder="Enter relationship" autocomplete="nope"/>
          </div>
          <div class="input-field">
            <input type="text" name="phone" placeholder="Enter phone" id="phn" required pattern="^[6-9]\d{9}$" onkeyup="return add()" title="Please enter a valid phone number"/>
          </div>
          <span class="msg" id="msg2"></span>
          <div class="input-field">
            <input type="password" name="password" placeholder="Password"/>
          </div>
          <div class="input-field">
            <input type="password" name="cpassword" placeholder="confirm password" onkeyup="return add()"   id="cpass"/>
          </div>
          <span class="msg" id="msg1"></span>
          <a href="#" class="link">Forgot Your Password?</a>
        </div>
        <div class="action">
        <button onclick()=window.location.href="sign.php">Sign in</button>
          <button type="submit" >Register</button>
         
        </div>
      </form>
    </div>
    <!-- partial -->
    <!-- <script  src="./script.js"></script> -->
  </body>
</html>